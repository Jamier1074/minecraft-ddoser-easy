# Minecraft Server DDoS'er

## Synopsis

Do you want to troll an entire Minecraft server?
This app is for anyone that wants to DDoS some stupid kid's Minecraft server.  What you are seeing is a tool of evil, a tool of revenge.  This Minecraft hack works on all servers, and it's free!

## Download
**[Minecraft Server DDoSer DOWNLOAD](https://github.com/Lusin333/Minecraft-Server-DDoSer/releases/download/2020-08-09/Meinkraft.Server.DDoS.er.exe)**

## History
666 years ago, Lusin played on a Minecraft server named ShockNetwork hosted by a friend named FlamingPaw.  There were many good times, and Lusin dominated the server with epic skills and awesome hacks.

Until one day, FlamingPaw said Spongebob was a better anime than My Little Pony.

Lusin was outraged to hear this total lie from FlamingPaw.  In his fury, Lusin used the Minecraft Server DDoS'er to destroy FlamingPaw's Server.  Within a single day, FlamingPaw apologized and accepted that Lusin was right:  My Little Pony is the greatest anime of all-time.
***

## Preview Image

<div id="Preview Images">
</a>
<img src="https://raw.githubusercontent.com/Lusin333/Meinkraft-Server-DDoSer/master/Meinkraft%20Server%20DDoS'er%20Preview%20Pic.png" data-canonical-src="https://raw.githubusercontent.com/Lusin333/Meinkraft-Server-DDoSer/master/Meinkraft%20Server%20DDoS'er%20Preview%20Pic.png" width="480" />
</a>
<img src="https://raw.githubusercontent.com/Lusin333/Meinkraft-Server-DDoSer/master/Meinkraft%20Server%20DDOS'er%20Icon%20-%20Lusin.png" data-canonical-src="https://raw.githubusercontent.com/Lusin333/Meinkraft-Server-DDoSer/master/Meinkraft%20Server%20DDOS'er%20Icon%20-%20Lusin.png" width="225" />
</div>

## Follow Lusin333
* 🎥 [Lusin's Youtube](https://www.Youtube.com/c/Lusin333?sub_confirmation=1)
* 🐦 [Lusin's Twitter](https://Twitter.com/Lusin333)
* 📸 [Lusin's Instagram](https://www.instagram.com/Lusin.333/)
* 👩‍💻 [Lusin's Github](https://Github.com/Lusin333)

***
![visitor badge](https://visitor-badge.glitch.me/badge?page_id=Lusin.visitor-badge&left_text=Minecraft%20Server%20DDoS'er%20Visitors)
